console.log("--- CLASSES ---");


interface Point {
    x: number,
    y: number
}

function distance(p1: Point, p2: Point): number {
    return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
}


console.log(
    distance({ x: 0, y: 3 }, { x: 4, y: 0 })
);

// ------

enum TodoState {
    Todo = 0,
    InProgress = 1,
    Done = 2,
    WontDo = 9
}

interface Todo {
    id?: number,
    title: string,
    description: string,
    state: TodoState
}

class TodoService {
    static lastId: number = 0;
    todos: Todo[] = [];

    getNewId(): number {
        TodoService.lastId += 1;
        return TodoService.lastId;
    }

    getAll(): Todo[] {
        return this.todos;
    }

    addTodo(todo: Todo): void {
        const newId = this.getNewId();
        this.todos.push({
            ...todo,
            id: newId
        });
    }

    getTodo(id: number): Todo {
        for (const t of this.todos) {
            if (t.id === id) {
                return t;
            }
        }
        return null;
    }

}

let ts = new TodoService();

ts.addTodo(
    {
        title: "aaa",
        description: "dklcjsdkjsl",
        state: TodoState.InProgress
    }
);

ts.addTodo(
    {
        title: "bbb",
        description: "faaddsfdfsdf",
        state: TodoState.InProgress
    }
);

ts.addTodo(
    {
        title: "ccc",
        description: "shdkjhsldkvh",
        state: TodoState.InProgress
    }
);


console.log(ts.getAll());

console.log(ts.getTodo(2));