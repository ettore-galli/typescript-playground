function main() {
    console.log("BASIC TYPES")

    const myStr: string = "Hello, World!";
    const myNumber: number = 9.81;
    const myBool: boolean = true;

    console.log(myStr, myNumber, myBool);

    const myNumbers: number[] = [3.14, 2.71, 9.81];

    console.log(myNumbers);

    function sum(a: number, b: number): number {
        return a + b
    }

    console.log(sum(3, 4));

    // console.log(sum(3, "quattro"));
    // Argument of type '"quattro"' is not assignable to parameter of type 'number'.

    myNumbers.forEach((n) => console.log(n * 2));

    // ["a", "b"].forEach((n) => console.log(n * 2));
    // types.ts:25:41 - error TS2362: The left-hand side of an arithmetic operation must be of type 'any', 'number', 'bigint' or an enum type.


    const coso: { nome: string, anno: number, peso?: number } = { nome: "ettore", anno: 1972 };
    console.log(coso);
    const coso2: { nome: string, anno: number, peso?: number } = { nome: "ettore", anno: 1972, peso: 3.14159 };
    console.log(coso2);
    // const coso3: { nome: string } = { nome: "ettore", anno: 1972 };
    // console.log(coso3);
    // types.ts:33:55 - error TS2322: Type '{ nome: string; anno: number; }' is not assignable to type '{ nome: string; }'.
    // Object literal may only specify known properties, and 'anno' does not exist in type '{ nome: string; }'.

    // 33     const coso3: { nome: string } = { nome: "ettore", anno: 1972 };


    function sette(multiplo: string | number) {
        if (typeof multiplo === "number") {
            return multiplo + 7;
        } else {
            return multiplo + " + 7";
        }
    }
    console.log(sette("tre"));
    console.log(sette(3));

    type Persona = { nome: string, anno: number };

    function stampaPersona(u: Persona) {
        console.log(u.nome);
        console.log(u.anno);
    }

    stampaPersona({ nome: "ettore", anno: 1972 });

    interface HomoSapiens { nome: string, anno: number };

    function stampaHomoSapiens(u: HomoSapiens) {
        console.log(u.nome);
        console.log(u.anno);
    }

    stampaHomoSapiens({ nome: "ettore", anno: 1972 });

    const n = 3.1415 as number;
    console.log(n);

    // const n2 = 3.1415 as boolean;

    const n3 = (3.1415 as any) as string;
    console.log(n3);


    let possibili: "A" | "B" | "C";

    possibili = "A";
    possibili = "B";
    possibili = "C";

    // possibili = "D";
    // Type '"D"' is not assignable to type '"A" | "B" | "C"'.

    type Alignments = "left" | "right" | "center"
    function printText(s: string, alignment: "left" | "right" | "center") {
        // ...
    }
    function printText2(s: string, alignment: Alignments) {
        // ...
    }
    printText("Hello, world", "left");
    printText(null, "left");
    // printText("G'day, mate", "centre");
    // Argument of type '"centre"' is not assignable to parameter of type '"left" | "right" | "center"'
    // printText2("G'day, mate", "centre");
    // Argument of type '"centre"' is not assignable to parameter of type '"left" | "right" | "center"'

    function printAll(strs: string | string[] | null) {

        if (strs && typeof strs === "object") {
            for (const s of strs) {
                console.log(s);
            }
        } else if (typeof strs === "string") {
            console.log("*" + strs + "*");
        }
    }

    printAll("");

    function padLeft(padding: number | string, input: string) {
        if (typeof padding === "number") {
            return new Array(padding + 1).join("-") + input;
        }
        return padding + input;
    }

    console.log(padLeft(3, "ciao"));
    console.log(padLeft("xxx", "ciao"));

    function messWithTypes() {
        let result: number | string = null;
        const cases: number[] = [1, 10, 100];
        for (let i = 0; i < cases.length; i++) {
            if (cases[i] < 11) {
                result = cases[i];
            } else {
                result = "Too big";
            }
            console.log(result, typeof result);

        }
    }

    messWithTypes();


    function isTypeofNumber(n:number | string): n is number{
        return typeof n === "number";
    }

    console.log(isTypeofNumber(1), isTypeofNumber("uno"));


}

main();