var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
console.log("--- CLASSES ---");
function distance(p1, p2) {
    return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
}
console.log(distance({ x: 0, y: 3 }, { x: 4, y: 0 }));
// ------
var TodoState;
(function (TodoState) {
    TodoState[TodoState["Todo"] = 0] = "Todo";
    TodoState[TodoState["InProgress"] = 1] = "InProgress";
    TodoState[TodoState["Done"] = 2] = "Done";
    TodoState[TodoState["WontDo"] = 9] = "WontDo";
})(TodoState || (TodoState = {}));
var TodoService = /** @class */ (function () {
    function TodoService() {
        this.todos = [];
    }
    TodoService.prototype.getNewId = function () {
        TodoService.lastId += 1;
        return TodoService.lastId;
    };
    TodoService.prototype.getAll = function () {
        return this.todos;
    };
    TodoService.prototype.addTodo = function (todo) {
        var newId = this.getNewId();
        this.todos.push(__assign({}, todo, { id: newId }));
    };
    TodoService.prototype.getTodo = function (id) {
        for (var _i = 0, _a = this.todos; _i < _a.length; _i++) {
            var t = _a[_i];
            if (t.id === id) {
                return t;
            }
        }
        return null;
    };
    TodoService.lastId = 0;
    return TodoService;
}());
var ts = new TodoService();
ts.addTodo({
    title: "aaa",
    description: "dklcjsdkjsl",
    state: TodoState.InProgress
});
ts.addTodo({
    title: "bbb",
    description: "faaddsfdfsdf",
    state: TodoState.InProgress
});
ts.addTodo({
    title: "ccc",
    description: "shdkjhsldkvh",
    state: TodoState.InProgress
});
console.log(ts.getAll());
console.log(ts.getTodo(2));
