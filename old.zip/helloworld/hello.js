function saluto(persona) {
    return "-- Ciao, " + persona.nome + " del " + persona.anno + " ---";
}
console.log(saluto({ nome: "Ettore", anno: 1972 }));
